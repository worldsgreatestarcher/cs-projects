#include <stdlib.h>

#include <string.h>

#include <stdio.h>

#include "jagged.h"

// Initialize a jagged array object with the given number of bins.
// The array is initially unpacked.
void jagged_init(jagged_t * jagged, int bins) {
  jagged -> size = 0;
  jagged -> number_of_bins = bins;
  jagged -> bins = (entry_t ** ) calloc(bins, sizeof(entry_t * ));
  jagged -> packed_values = NULL;
  jagged -> offsets = NULL;
}

void jagged_free(jagged_t * jagged) {
  // if packed_values are not null, free the packed values and the offsets
  if (jagged -> packed_values != NULL) {
    free(jagged -> packed_values);
    free(jagged -> offsets);
  } else {
    // iterate through array
    for (int i = 0; i < jagged -> number_of_bins; i++) {
      entry_t * ptr = jagged -> bins[i];
      while (ptr != NULL) {
        // free the node
        entry_t * next = ptr -> next;
        free(ptr);
        ptr = next;
      }
    }
    // free the bins
    free(jagged -> bins);
  }
}

// Return the number of elements in the jagged array
int jagged_size(jagged_t * jagged) {
  return jagged -> size;
}

// Return the number of bins
int jagged_bins(jagged_t * jagged) {
  return jagged -> number_of_bins;
}

// Return the number of slots in the given bin
int jagged_slots(jagged_t * jagged, int bin) {
  //  if int bin is negative or greater than the number of bins, return -1
  if (bin < 0 || bin >= jagged -> number_of_bins) {
    return -1;
  }
  entry_t * ptr = jagged -> bins[bin];
  int count = 0;  // variable to count number of slots

  //  while ptr is not null, inc counter and set ptr equal to next bin
  while (ptr != NULL) {
    count++;
    ptr = ptr -> next;
  }
  return count;  // return number of slots
}

// Return the element stored at the given bin and slot number.
// Success is set to 0 if the element was found, or -1 otherwise.
// If success is -1, 0 is returned.
int jagged_element(jagged_t * jagged, int bin, int slot, int * success) {
  * success = -1;

  // Check if the array is packed
  if (jagged -> packed_values != NULL) {
    // Calculate the start index of the bin's elements
    // in the packed_values array
    int start_index = jagged -> offsets[bin];
    int end_index = jagged -> offsets[bin + 1];

    // Check if the bin is empty
    if (start_index == end_index) {
      return 0;
    }

    // Check if the slot is within bounds
    if (slot < 0 || slot >= end_index - start_index) {
      return 0;
    }

    // Retrieve the element from the packed_values array
    * success = 0;
    return jagged -> packed_values[start_index + slot];
  }

  // If the array is not packed, access the bin directly
  if (bin < 0 || bin >= jagged -> number_of_bins) {
    return -1;
  }

  entry_t * packed_ptr = jagged -> bins[bin];
  int packed_count = 0;
  while (packed_ptr != NULL) {
    if (packed_count == slot) {
      * success = 0;
      return packed_ptr -> value;
    }
    packed_count++;
    packed_ptr = packed_ptr -> next;
  }
  return 0;

  // if int bin is negative or greater than the number of bins, return -1
  if (bin < 0 || bin >= jagged -> number_of_bins) {
    return -1;
  }

  entry_t * ptr = jagged -> bins[bin];
  int count = 0;
  while (ptr != NULL) {
    if (count == slot) {
      * success = 0;
      return ptr -> value;
    }
    count++;
    ptr = ptr -> next;
  }
  return 0;
}

// Add an element to the bin. Return 0 is the element was
// added, or -1 if the representation is packed
int jagged_add(jagged_t * jagged, int bin, int element) {
  //  return -1 if representation is packed
  if (jagged -> packed_values != NULL) {
    return -1;
  }

  // if int bin is negative or greater than the number of bins, return -1
  if (bin < 0 || bin >= jagged -> number_of_bins) {
    return -1;
  }
  // create a new node
  entry_t * new_ptr = (entry_t * ) malloc(sizeof(entry_t));
  new_ptr -> value = element;  // set the value of the node to element
  new_ptr -> next = NULL;
  entry_t * cur = jagged -> bins[bin];
  if (jagged -> bins[bin] == NULL) {
    jagged -> bins[bin] = new_ptr;
  } else {
    while (cur -> next != NULL) {
      cur = cur -> next;
    }
    cur -> next = new_ptr;
  }
  jagged -> size++;  // increment size of jagged

  return 0;
}

// Remove the element from the given bin and slot. Return 0 on success,
// or -1 if the representation was packed or element not found.
int jagged_remove(jagged_t * jagged, int bin, int slot) {
  // if array is packed, return =1

  if (jagged -> packed_values != NULL) {
    return -1;
  }
  // Creating a temporary variable pointing to head
  entry_t * temp = jagged -> bins[bin];
  if (slot == 0) {
    // Advancing the head pointer
    jagged -> bins[bin] = jagged -> bins[bin] -> next;
    temp -> next = NULL;
    free(temp);  // Node is deleted
  } else {
    for (int i = 0; i < slot - 1; i++) {
      temp = temp -> next;
    }
    // temp pointer points to the previous node of the node to be deleted
    // del pointer points to the node to be deleted
    entry_t * del = temp -> next;
    temp -> next = temp -> next -> next;
    del -> next = NULL;
    free(del);  // Node is deleted
  }
  jagged -> size--;

  return 0;
}

// Unpack the jagged array. Return 0 if successful or -1 if the array is
// already unpacked.
int jagged_unpack(jagged_t * jagged) {
  // Step 1: Check if already unpacked and return -1 if so
  if (jagged -> packed_values == NULL) {
    return -1;
  }

  // Step 2: Allocate memory for unpacked representation
  jagged -> bins = (entry_t **) malloc(jagged -> number_of_bins
  * sizeof(entry_t * ));

  if (jagged -> bins == NULL) {
    // Memory allocation failed, handle error
    return -1;
  }

  // Step 3: Iterate over each bin
  for (int i = 0; i < jagged -> number_of_bins; i++) {
    int offset = jagged -> offsets[i];
    if (offset != jagged -> offsets[i + 1]) {
      // Bin is not empty, create linked list and populate with elements
      entry_t * head = NULL;
      entry_t * current = NULL;
      for (int j = offset; j < jagged -> offsets[i + 1]; j++) {
        entry_t * new_entry = (entry_t * ) malloc(sizeof(entry_t));
        new_entry -> value = jagged -> packed_values[j];
        new_entry -> next = NULL;
        if (head == NULL) {
          head = new_entry;
          current = head;
        } else {
          current -> next = new_entry;
          current = current -> next;
        }
      }
      jagged -> bins[i] = head;
    } else {
      // Bin is empty
      jagged -> bins[i] = NULL;
    }
  }

  // Step 4: Free memory associated with packed representation
  free(jagged -> packed_values);
  free(jagged -> offsets);

  // Step 5: Set packed representation to NULL
  jagged -> packed_values = NULL;
  jagged -> offsets = NULL;

  return 0;
}
// Pack the jagged array. Return 0 if successful or -1 if the array
// is already packed.
int jagged_pack(jagged_t* jagged) {
    // Step 1: Check if already packed and return -1 if so
    if (jagged->packed_values != NULL) {
        return -1;
    }

    // Step 2: Allocate memory for packed representation
    jagged->packed_values = (int*)malloc(jagged->size * sizeof(int));
    jagged->offsets = (int*)malloc((jagged->number_of_bins + 1) * sizeof(int));

    if (jagged->packed_values == NULL || jagged->offsets == NULL) {
        // Memory allocation failed, handle error
        return -1;
    }

    // Step 3: Iterate over each bin
    // and copy elements into the packed_values array
    int index = 0;
    for (int i = 0; i < jagged->number_of_bins; i++) {
        entry_t* current_entry = jagged->bins[i];
        jagged->offsets[i] = index;  // Update offset for the current bin
        while (current_entry != NULL) {
            jagged->packed_values[index++] = current_entry->value;
            current_entry = current_entry->next;
        }
    }
    // Update offset for the end of packed_value
    jagged->offsets[jagged->number_of_bins] = index;
    free(jagged->bins);  // Free memory for the array of pointers
    jagged->bins = NULL;

    return 0;  // Success
}

// Print a jagged array out. Useful for debugging
void jagged_print(jagged_t* jagged) {
     printf("Jagged Array:\n");
    if (jagged->packed_values != NULL) {
        printf("Packed Representation:\n");
        printf("Packed Values:\n");
        for (int i = 0; i < jagged->size; i++) {
            printf("%d ", jagged->packed_values[i]);
        }
        printf("\nOffsets:\n");
        for (int i = 0; i <= jagged->number_of_bins; i++) {
            printf("%d ", jagged->offsets[i]);
        }
        printf("\n");
    } else {
        printf("Unpacked Representation:\n");
        for (int i = 0; i < jagged->number_of_bins; i++) {
            printf("Bin %d:", i);
            if (jagged->bins[i] == NULL) {
                printf(" Empty\n");
            } else {
                entry_t* ptr = jagged->bins[i];
                while (ptr != NULL) {
                    printf(" %d", ptr->value);
                    ptr = ptr->next;
                }
                printf("\n");
            }
        }
    }
}
