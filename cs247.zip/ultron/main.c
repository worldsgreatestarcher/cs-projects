#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "ultron.h"

char temp; // temp variable for scanf
Ultron ultron; // ultron struct
int num = 32; // number of instructions
int instructions[32]; // array of instructions

int main(int argc, char** argv) {
    int opt = 0;
    // while loop to check for command line arguments
    while ((opt = getopt(argc, argv, "i:f:"))!= -1) {
         switch (opt) {
            // case for -i: load instructions from input
            // run and print result and dump
            case 'i':  
                num = atoi(argv[optind -1]);

                for (int i = 0; i < num; i++){
                    scanf("%d", &instructions[i]);
                    getchar();  // remove extra line
                }
                ultron_load(&ultron, num, instructions);
                printf("Result: %d\n", ultron_run(&ultron));
                ultron_dump(&ultron);
                break;
            // case for -f: load instructions from file
            // run and print result and dump
            // close file
            case 'f':
                if (argc >= 3 && strcmp(argv[1], "-f") == 0) {
                    FILE* file = fopen(argv[2], "r");
                    int i = 0;
                    int num = 0;
                    while (fscanf(file, "%d", &num) > 0) {
                        instructions[i] = num;
                        i++;
                    }
                    fclose(file);
                }
                    ultron_load(&ultron, num, instructions);
                    printf("Result: %d\n", ultron_run(&ultron));
                    ultron_dump(&ultron);
                    break;

                }
         }
    }
