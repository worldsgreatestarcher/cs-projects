#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ultron.h"

int memory[32];
int pc = 0;
int accumulator = 0;

// initalizes the ultron computer
void ultron_init(Ultron* ultron) {
    for (int i = 0; i < ULTRON_MEMORY_SIZE; i++) {
        memory[i] = 0;
    }
}
// prints the pc and accumulator of ultron
void ultron_dump(Ultron* ultron) {
    printf("PC: %d\n", pc);
    printf("AC: %d\n", accumulator);
    for (int i = 0; i< ULTRON_MEMORY_SIZE; i++) {
        printf("%2d %4d\n", i, memory[i]);
    }
}

// returns the value at the location in memory
int ultron_memory(Ultron* ultron, int location) {
    return memory[location];
}

// returns the value of the accumulator
int ultron_accumulator(Ultron* ultron) {
    return accumulator;
}

// returns the value of the pc
int ultron_pc(Ultron* ultron) {
    return pc;
}

// loads instructions into memory
void ultron_load(Ultron* ultron, int size, int* instructions) {
    for (int i = 0; i < size; i++) {
        memory[i] = instructions[i];
    }
}

int ultron_run(Ultron* ultron) {
    int instruction = memory[pc];
    int operation = instruction/100;
    int operand = instruction%100;

    // if operation is not the exit operation, run ultron
    while (operation != 43) {
        instruction = memory[pc];
        operation = instruction/100;
        operand = instruction%100;
        
        // if operation is not a valid operation, return -1
        if (operation != 10
        && operation != 11
        && operation != 20
        && operation != 21
        && operation != 30
        && operation != 31
        && operation != 40
        && operation != 43) {
            return -1;
        }
        // if operand is not a valid operand, return -2operand is les than zero or exceeds memory size, return exit code
        if (operand < 0 || operand > 32) {
            return -2;
        }
        // if the program counter is less than zero or exceeds memory size, return -3
        if (pc < 0 || pc > 32) {
            return -3;
        }

        // switch statement for each operation
        switch (operation) {
            // if operation is 10, ask for input and store in memory
            // then increment the program counter
            case 10:
                printf("? ");
                scanf("%d", &memory[operand]);
                pc+=1;
                break;
            // if operation is 11, print the value in memory
            // then increment the program counter
            case 11:
               printf("= %d\n", memory[operand]);
               pc+=1;
                break;
            // if operation is 20, store the value in memory
            // in the accumulator
            // then increment the program counter
            case 20:
                accumulator = memory[operand];
                pc+=1;
                break;
            // if operation is 21, store the value in the accumulator
            // in memory
            // then increment the program counter
            case 21:
                memory[operand] = accumulator;
                pc+=1;
                break;
            // if operation is 30, add the value in memory
            // to the accumulator
            // then increment the program counter
            case 30:
                accumulator += memory[operand];
                pc+=1;
                break;
            // if operation is 31, subtract the value in memory
            // from the accumulator
            // then increment the program counter
            case 31:
                accumulator -= memory[operand];
                pc+=1;
                break;
            // if operation is 40, if the accumulator is less than 0
            // then set the program counter to the value in memory
            // otherwise increment the program counter
            case 40:
                if (accumulator < 0) {
                    pc = operand;
                } else {
                    pc+=1;
                }
                 break;
            // if operation is 43, return 0 and end the program
            case 43:
                return 0;
                break;

        }
    }
    return 0;
}
