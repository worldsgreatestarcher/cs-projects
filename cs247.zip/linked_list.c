#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int value;
    struct node* next;
    struct node* previous;
} Node;

struct node* make_node(int value, Node* next, Node* previous) {
    Node* new_node = malloc(sizeof(Node));
    if (new_node != NULL) {
        new_node->value = value;
        new_node->next = next;
        new_node->previous = previous;
    }
    return new_node;
}

void add_back(Node** list, int value) {
    Node* new_node = make_node(value, NULL, NULL);
    if (*list == NULL) {
        *list = new_node;
    } else {
        Node* current = *list;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = new_node;
        new_node->previous = current;
    }
}

void print_list(Node* list, int backwards) {
   if (backwards == 1) {
       Node* current = list;
       while (current->next != NULL) {
           current = current->next;
       }
       while (current != NULL) {
           printf("%d\n", current->value);
           current = current->previous;
       }
   } else {
       Node* current = list;
       while (current != NULL) {
           printf("%d\n", current->value);
           current = current->next;
       }
   }
}

void remove_node(Node** list, int value) {
    Node* current = *list;
    while (current != NULL) {
        if (current->value == value) {
            if (current->previous == NULL) {
                *list = current->next;
            } else {
                current->previous->next = current->next;
            }
            if (current->next != NULL) {
                current->next->previous = current->previous;
            }
            free(current);
            return;
            }
        current = current->next;
        }
    }

int main(int argc, char** argv) {
    struct node* list = NULL;        // initially the tree is NULL
    add_back(&list, 42);
    add_back(&list, 13);
    add_back(&list, 50);
    add_back(&list, 15);
    add_back(&list, 2);

    print_list(list, 0);                
    print_list(list, 1);   

    remove_node(&list, 15);   
    remove_node(&list, 13);   
    remove_node(&list, 42);         

    print_list(list, 0);                

}




