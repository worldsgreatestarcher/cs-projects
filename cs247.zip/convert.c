#include <stdio.h>

#include <stdlib.h>

#include <string.h>

void print_bin(int decimal) {
  if (decimal == 0) {
    printf("0");
    return;
  }
  int binary[32];
  int i = 0;
  while (decimal > 0) {
    binary[i] = decimal % 2;
    decimal = decimal / 2;
    i++;
  }
  for (int j = i - 1; j >= 0; j--) {
    printf("%d", binary[j]);
    if (j % 4 == 0 && j != 0) {
      printf(" ");
    }
  }
}

void print_hex(int decimal) {
  if (decimal == 0) {
    printf("0x0");
    return;
  }
  printf("0x");
  int quotient = 0;
  int i = 1, j, temp;
  char hexadecimalNumber[100];

  quotient = decimal;

  while (quotient != 0) {
    temp = quotient % 16;

    // To convert integer into character
    if (temp < 10) {
      temp = temp + 48;
    } else {
      temp = temp + 87;  // lowercase letter offset
    }
    hexadecimalNumber[i++] = temp;
    quotient = quotient / 16;
  }
  for (j = i - 1; j > 0; j--) {
    printf("%c", hexadecimalNumber[j]);
    if ((j - 1) % 2 == 0 && j > 1) {
      printf(" ");
    }
  }
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: ./convert [-x|-b] num1 [num2 ...]\n");
        return 1;
    }

    if (strcmp(argv[1], "-x") != 0 && strcmp(argv[1], "-b") != 0) {
        printf("Usage: ./convert [-x|-b] num1 [num2 ...]\n");
        return 1;
    }

    for (int i = 2; i < argc; i++) {
        if (i > 2) {
            printf("\n");
        }
        if (argv[i][0] == '-') {
            printf("Usage: ./convert [-x|-b] num1 [num2 ...]\n");
            return 1;
        }
        int value = atoi(argv[i]);
        printf("%d=", value);
        if (strcmp(argv[1], "-x") == 0) {
            print_hex(value);
        } else if (strcmp(argv[1], "-b") == 0) {
            print_bin(value);
        }
    }

    printf("\n");

    return 0;
}
