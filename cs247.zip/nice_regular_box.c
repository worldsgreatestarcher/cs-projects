#include <stdio.h>

#include <string.h>

void printBorders(int maxLength) {
  printf("+");
  for (int i = 0; i < maxLength + 2; i++) {
    printf("+");
  }
  printf("+\n");
}

void printRegularBox(int lines, char input[lines][200]) {
  int maxLength = 0;

  // find the length of the longest line
  for (int i = 0; i < lines; i++) {
    int length = strlen(input[i]);
    if (length > maxLength) {
      maxLength = length;
    }
  }

  // print the top border
  printBorders(maxLength);

  for (int i = 0; i < lines; ++i) {
    printf("+ %-*s +\n", maxLength, input[i]);
  }
  // print the bottom border
  printBorders(maxLength);
}
int main() {

  // read number of lines
  int numLines = 0;
  scanf("%d", & numLines);
  getchar(); // consume newline

  char input[numLines][200];
  for (int i = 0; i < numLines; i++) {
    fgets(input[i], sizeof(input[i]), stdin);

    // remove newline character
    input[i][strlen(input[i]) - 1] = '\0';
  }
  printRegularBox(numLines, input);
  return 0;
}