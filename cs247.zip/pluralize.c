#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

bool ends_with(const char* s, const char* t) {
    size_t s_len = strlen(s);
    size_t t_len = strlen(t);

    if (t_len > s_len) {
        return false;
    }

    const char* s_end = s + s_len - t_len;

    return strcmp(s_end, t) == 0;
}

void pluralizeWord(char* s) {
    int len = strlen(s);

    if (ends_with(s, "ife")) {
        // Ends in -ife
        strcpy(&s[len-2], "ves");
    } else if (ends_with(s, "sh") || ends_with(s, "ch")) {
        // Ends in -sh or -ch
        strcat(s, "es");
    } else if (ends_with(s, "us")) {
        // Ends in -us
        strcpy(&s[len-2], "i");
    } else if (ends_with(s, "ay") || ends_with(s, "oy") || ends_with(s, "ey") || ends_with(s, "uy")) {
        // Ends in -ay, -oy, -ey, -uy
        strcat(s, "s");
    } else if (ends_with(s, "y")) {
        // Ends in -y
        strcpy(&s[len-1], "ies");
    } else {
        // Default case, add an 's' to the end
        strcat(s, "s");
    }
}

int main() {
    int num;
    char word[100];

    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Enter a word: ");
    scanf("%s", word);

    if (num == 1) {
        printf("%d %s\n", num, word);
    } else {
        pluralizeWord(word);
        printf("%d %s\n", num, word);
    }


    return 0;

}
