// to calculate page size divide 
// memory size by page size
// in this case
// 256 bytes / 16 bytes = 16 pages

// the page table has 16 entries
// the virtual address has 4 bits

// page size is 16 bytes
// 4 bit page offset
// 12 bit page number

// page number is 24 / 16 = 1
// frame for page 1 is 6
// physical memory address is 6
// offset = 24 % 16 = 8


#include <stdio.h>

int main() {
    int bits, page_size, address;
    int page_bits, offset_bits;

   printf("How many bits? ");
   scanf("%d", &bits);
   
   printf("Page size in bytes? ");
   scanf("%d", &page_size);
    

    // calculate page bits
    // and offset bits
    page_bits = 0;
    while ((1 << page_bits) < page_size) {
        page_bits++;
    }
    offset_bits = bits - page_bits;
    printf("Page bits:%d, Offset bits:%d\n", page_bits, offset_bits);

    printf("Enter the address in hex: ");
    scanf("%x", &address);

    // extract page number and offset
    int page_number = address / page_size;
    int offset = address % page_size;
    printf("Page No=0x%x, Offset=0x%x\n", page_number, offset);

    return 0;
}

// page number = virtual address / page size = 24 / 4096 = 0
// offset = virtual address % page size = 24 % 4096 = 24
// page number = 0
// offset = 24
// physical address = offset
// physical addrees = 24
